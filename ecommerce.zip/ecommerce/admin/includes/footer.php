<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 666 INFERNO<a href="#">GRUPO T.I CHORA NÃO</a></strong>
</footer>