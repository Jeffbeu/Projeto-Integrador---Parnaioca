<?php
	include 'includes/session.php';

	if(isset($_GET['delete'])){
		$id = $_GET['id'];
		
		$conn = $pdo->open();

		try{
			$stmt = $conn->prepare("DELETE FROM products WHERE id=:id");
			$stmt->execute(['id'=>$id]);

			$_SESSION['success'] = 'Produto excluído com sucesso';
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	else{
		$_SESSION['error'] = 'Selecione o produto para excluir primeiro';
	}

	header('location: products.php');
	
?>