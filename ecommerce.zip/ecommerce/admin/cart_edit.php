<?php
	include 'includes/session.php';

	if(isset($_GET['edit'])){
		$userid = $_GET['userid'];
		$cartid = $_GET['cartid'];
		$quantity = $_GET['quantity'];

		$conn = $pdo->open();

		try{
			$stmt = $conn->prepare("UPDATE cart SET quantity=:quantity WHERE id=:id");
			$stmt->execute(['quantity'=>$quantity, 'id'=>$cartid]);

			$_SESSION['success'] = 'Quantidade atualizada com sucesso';
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}
		
		$pdo->close();

		header('location: cart.php?user='.$userid);
	}

?>